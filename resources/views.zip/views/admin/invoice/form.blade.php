@extends('layouts.backend.index')
@section('content')

<div class="page-header">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
      <li class="breadcrumb-item"><a href="{{ route('admin.invoice') }}">invoice</a></li>
      
    </ol>
    <!-- <h1 class="page-title">Add Category</h1> -->
  </div>
  <div class="page-content">
  <div class="panel">
  <div class="panel-body">
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <form action="{{ route('admin.send.invoice') }}" method="POST"  class="needs-validation" novalidate>
                @csrf
                <div class="form-row">
                  <div class="col-md-4 mb-3">
                    <label for="validationTooltip01">Name</label>
                    {{-- <input type="text" class="form-control" id="validationTooltip01" placeholder="First name" value="Mark" required> --}}
                    <select  class="form-control" id="validationTooltip01"  required>
                        @foreach ($user as $users)
                        <option value="{{ $users->id }}">{{ $users->first_name }} {{ $users->last_name }}</option>
                            
                        @endforeach
                    </select>
                  </div>
                  <div class="col-md-4 mb-3">
                    <label for="validationTooltip02">Group</label>
                    {{-- <input type="text" class="form-control" id="validationTooltip02" placeholder="Last name" value="Otto" required> --}}
                    <select  name="group_id" class="form-control" id="validationTooltip02"  required>
                        @foreach ($group as $groups)
                        <option value="{{ $groups->id }}">{{ $groups->name }}</option>
                            
                        @endforeach
                    </select>
                  </div>
                  <div class="col-md-4 mb-3">
                    <label for="validationTooltipUsername">Courses</label>
                    <div class="input-group">
                     
                      <select style="height: 40px" name="course_id[]" multiple="multiple" class="form-control" id="validationTooltip02"  required>
                        @foreach ($course as $courses)
                        <option value="{{ $courses->id }}">{{ $courses->course_title }}</option>
                            
                        @endforeach
                    </select>
                    </div>
                  </div>
                </div>
                <div class="form-row">
                    <div class="col-md-4 mb-3">
                      <label for="validationTooltip01">Category</label>
                      <select name="category_id"class="form-control" id="validationTooltip02"  required>
                        @foreach ($category as $categories)
                        <option value="{{ $categories->id }}">{{ $categories->name }}</option>
                            
                        @endforeach
                    </select>

                    </div>
                    <div class="col-md-4 mb-3">
                      <label for="validationTooltip02">Price</label>
                      <input type="number" name="price" class="form-control" id="validationTooltip02" placeholder="Price" required>
                  
                    </div>
                   
                  </div>
             
                <button class="btn btn-primary" type="submit">Submit form</button>
              </form>
              
             
        </div>
    </div>
</div>
</div>
</div>
</div>

@endsection

