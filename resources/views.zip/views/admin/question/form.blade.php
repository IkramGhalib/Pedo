@extends('layouts.backend.index')
@section('content')
<div class="page-header">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
    <li class="breadcrumb-item"><a href="">Question</a></li>
    <li class="breadcrumb-item active">Add</li>
  </ol>
  <h1 class="page-title">Add Question</h1>
</div>


<div class="page-content">

    <div class="panel">
      <div class="panel-body">
        <form method="POST" action="{{ route('admin.send.question') }}" id="userForm">
          {{ csrf_field() }}
          {{-- <input type="hidden" name="user_id" value="{{ $user->id }}"> --}}
          <div class="row">
          


            <div class="form-group col-md-4">
                <label class="form-control-label">Test</label>
                <select  class="form-control" name="test_id" required>
                  @foreach ($test as $tests)
                      <option value="{{ $tests->id }}">{{ $tests->test_title}}</option>
                  @endforeach
                  
                </select>
                @if ($errors->has('test_id'))
                <label class="error" for="test_id">{{ $errors->first('test_id') }}</label>
            @endif
                
                 
              </div>

            <div class="form-group col-md-2">
              <label class="form-control-label">Q.No</label>
              <input required type="text" class="form-control" name="question_no"
              placeholder="Question no"/>
              @if ($errors->has('question_no'))
                  <label class="error" for="question_no">{{ $errors->first('question_no') }}</label>
              @endif
            </div>
          
            <div class="form-group col-md-6">
              <label class="form-control-label">Question Name</label>
              
                <textarea  required type="text" class="form-control" name="question_name"
                placeholder="Question Name"></textarea>
                @if ($errors->has('question_name'))
                    <label class="error" for="question_name">{{ $errors->first('question_name') }}</label>
                @endif
            </div>
          
          <div class="form-group col-md-4">
            <label class="form-control-label">Option 1</label>
            <input type="text" class="form-control" placeholder="Option 1" name="opt_1"/>
            @if ($errors->has('opt_1'))
            <label class="error" for="opt_1">{{ $errors->first('opt_1') }}</label>
        @endif
        
          </div>

          <div class="form-group col-md-4">
            <label class="form-control-label">Option 2</label>
            <input type="text" class="form-control" placeholder="Option 2" name="opt_2"/>
            @if ($errors->has('opt_2'))
            <label class="error" for="opt_2">{{ $errors->first('opt_2') }}</label>
        @endif
        
          </div>

          <div class="form-group col-md-4">
            <label class="form-control-label">Option 3</label>
            <input type="text" class="form-control" placeholder="Option 3" name="opt_3"/>
            @if ($errors->has('opt_3'))
            <label class="error" for="opt_3">{{ $errors->first('opt_3') }}</label>
        @endif
        
          </div>

          <div class="form-group col-md-4">
            <label class="form-control-label">Option 4</label>
            <input type="text" class="form-control" placeholder="Option 4" name="opt_4"/>
            @if ($errors->has('opt_4'))
            <label class="error" for="opt_4">{{ $errors->first('opt_4') }}</label>
        @endif
        
          </div>



          <div class="form-group col-md-4">
            <label class="form-control-label">Correct Answer</label>
            <select name="correct_answer" class="form-control">
                <option value="a">Option 1</option>
                <option value="b">Option 2</option>
                <option value="c">Option 3</option>
                <option value="d">Option 4</option>

            </select>
              
            @if ($errors->has('correct_answer'))
                <label class="error" for="correct_answer">{{ $errors->first('correct_answer') }}</label>
            @endif
          </div>



         

         

          



          


        
          
        
          </div>
          <hr>
          <div class="form-group row">
            <div class="col-md-4">
              <button type="submit" class="btn btn-primary">Submit</button>
              <button type="reset" class="btn btn-default btn-outline">Reset</button>
            </div>
          </div>
          
        </form>
      </div>
    </div>
    
           
          <!-- End Panel Basic -->
    </div>



@endsection

